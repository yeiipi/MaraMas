--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE maramas2;
--
-- Name: maramas2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE maramas2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Colombia.1252';


ALTER DATABASE maramas2 OWNER TO postgres;

\connect maramas2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: package; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package (
    id_package integer NOT NULL,
    category character varying(50) NOT NULL,
    source_store character varying(50) NOT NULL,
    weight_box smallint NOT NULL,
    height_box smallint NOT NULL,
    width_box smallint NOT NULL,
    price numeric(12,2) NOT NULL,
    purchase_date date DEFAULT CURRENT_DATE NOT NULL,
    delivery_date date,
    id_container smallint NOT NULL,
    id_vehicle smallint NOT NULL,
    id_delivery smallint NOT NULL,
    estimated_delivery date DEFAULT (CURRENT_DATE + '2 days'::interval)
);


ALTER TABLE public.package OWNER TO postgres;

--
-- Name: package_id_package_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.package_id_package_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.package_id_package_seq OWNER TO postgres;

--
-- Name: package_id_package_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.package_id_package_seq OWNED BY public.package.id_package;


--
-- Name: package id_package; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package ALTER COLUMN id_package SET DEFAULT nextval('public.package_id_package_seq'::regclass);


--
-- Data for Name: package; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.package (id_package, category, source_store, weight_box, height_box, width_box, price, purchase_date, delivery_date, id_container, id_vehicle, id_delivery, estimated_delivery) FROM stdin;
\.
COPY public.package (id_package, category, source_store, weight_box, height_box, width_box, price, purchase_date, delivery_date, id_container, id_vehicle, id_delivery, estimated_delivery) FROM '$$PATH$$/3052.dat';

--
-- Name: package_id_package_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.package_id_package_seq', 1379, true);


--
-- Name: package package_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_pkey PRIMARY KEY (id_package);


--
-- Name: package package_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_category_fkey FOREIGN KEY (category) REFERENCES public.category(categoria);


--
-- Name: package package_id_container_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_container_fkey FOREIGN KEY (id_container) REFERENCES public.container(id_container);


--
-- Name: package package_id_delivery_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_delivery_fkey FOREIGN KEY (id_delivery) REFERENCES public.delivery_person(id_delivery);


--
-- Name: package package_id_vehicle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_vehicle_fkey FOREIGN KEY (id_vehicle) REFERENCES public.vehicle(id_vehicle);


--
-- PostgreSQL database dump complete
--

