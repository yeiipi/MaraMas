--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres4;
--
-- Name: postgres4; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres4 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Mexico.1252';


ALTER DATABASE postgres4 OWNER TO postgres;

\connect postgres4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: randomfloat_between(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.randomfloat_between(low integer, high integer) RETURNS integer
    LANGUAGE plpgsql STRICT
    AS $$
BEGIN
   RETURN random()* (high-low + 1) + low;
END;
$$;


ALTER FUNCTION public.randomfloat_between(low integer, high integer) OWNER TO postgres;

--
-- Name: randomint_between(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.randomint_between(low integer, high integer) RETURNS integer
    LANGUAGE plpgsql STRICT
    AS $$
BEGIN
   RETURN floor(random()* (high-low + 1) + low);
END;
$$;


ALTER FUNCTION public.randomint_between(low integer, high integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: administrator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.administrator (
    id_admin integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    address character varying(50) NOT NULL,
    phone_num character varying(10) NOT NULL,
    id_auth smallint NOT NULL
);


ALTER TABLE public.administrator OWNER TO postgres;

--
-- Name: administrator_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.administrator_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.administrator_id_admin_seq OWNER TO postgres;

--
-- Name: administrator_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.administrator_id_admin_seq OWNED BY public.administrator.id_admin;


--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    categoria character varying(255) NOT NULL
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: container; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.container (
    id_container integer NOT NULL,
    container_num smallint NOT NULL,
    capacity integer,
    address character varying(50)
);


ALTER TABLE public.container OWNER TO postgres;

--
-- Name: container_id_container_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.container_id_container_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.container_id_container_seq OWNER TO postgres;

--
-- Name: container_id_container_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.container_id_container_seq OWNED BY public.container.id_container;


--
-- Name: coordenadas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coordenadas (
    id_coords integer NOT NULL,
    "time" timestamp without time zone NOT NULL,
    lat double precision,
    lng double precision,
    id_vehicle character varying(10) NOT NULL
);


ALTER TABLE public.coordenadas OWNER TO postgres;

--
-- Name: coordenadas_id_coords_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coordenadas_id_coords_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coordenadas_id_coords_seq OWNER TO postgres;

--
-- Name: coordenadas_id_coords_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coordenadas_id_coords_seq OWNED BY public.coordenadas.id_coords;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id_customer integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    address character varying(50) NOT NULL,
    phone_num character varying(10) NOT NULL,
    pay_method character varying(20),
    id_auth smallint NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_customer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_customer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_customer_seq OWNER TO postgres;

--
-- Name: customer_id_customer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_customer_seq OWNED BY public.customer.id_customer;


--
-- Name: delivery_person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_person (
    id_delivery integer NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    address character varying(50) NOT NULL,
    phone_num character varying(10) NOT NULL,
    id_auth smallint NOT NULL,
    id_vehicle smallint,
    id_container smallint,
    status boolean DEFAULT false NOT NULL
);


ALTER TABLE public.delivery_person OWNER TO postgres;

--
-- Name: delivery_person_id_delivery_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivery_person_id_delivery_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivery_person_id_delivery_seq OWNER TO postgres;

--
-- Name: delivery_person_id_delivery_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivery_person_id_delivery_seq OWNED BY public.delivery_person.id_delivery;


--
-- Name: dispatcher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dispatcher (
    id_dispatcher smallint NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20) NOT NULL,
    address character varying(50) NOT NULL,
    phone_num character varying(10) NOT NULL,
    status smallint NOT NULL,
    id_auth smallint NOT NULL,
    id_container smallint,
    id_number integer
);


ALTER TABLE public.dispatcher OWNER TO postgres;

--
-- Name: dispatcher_id_dispatcher_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dispatcher_id_dispatcher_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dispatcher_id_dispatcher_seq OWNER TO postgres;

--
-- Name: dispatcher_id_dispatcher_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dispatcher_id_dispatcher_seq OWNED BY public.dispatcher.id_dispatcher;


--
-- Name: package; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.package (
    id_package integer NOT NULL,
    category character varying(50) NOT NULL,
    source_store character varying(50) NOT NULL,
    weight_box smallint NOT NULL,
    height_box smallint NOT NULL,
    width_box smallint NOT NULL,
    price numeric(12,2) NOT NULL,
    purchase_date date DEFAULT CURRENT_DATE NOT NULL,
    delivery_date date,
    id_container smallint NOT NULL,
    id_vehicle smallint NOT NULL,
    id_delivery smallint NOT NULL,
    estimated_delivery date DEFAULT (CURRENT_DATE + '2 days'::interval)
);


ALTER TABLE public.package OWNER TO postgres;

--
-- Name: package_id_package_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.package_id_package_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.package_id_package_seq OWNER TO postgres;

--
-- Name: package_id_package_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.package_id_package_seq OWNED BY public.package.id_package;


--
-- Name: tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo (
    id_tipo integer NOT NULL,
    tipo character varying(30) NOT NULL
);


ALTER TABLE public.tipo OWNER TO postgres;

--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_id_tipo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_id_tipo_seq OWNER TO postgres;

--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_id_tipo_seq OWNED BY public.tipo.id_tipo;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_name character varying(255) NOT NULL,
    user_lastname character varying(255) NOT NULL,
    user_email character varying(255) NOT NULL,
    user_password character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: vehicle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicle (
    id_vehicle integer NOT NULL,
    capacity smallint NOT NULL,
    license_plate character varying(10) NOT NULL,
    mechanical_status boolean NOT NULL,
    latitud double precision,
    longitud double precision,
    tiempo timestamp without time zone,
    model character varying(30),
    brand character varying(30),
    tipo smallint
);


ALTER TABLE public.vehicle OWNER TO postgres;

--
-- Name: vehicle_id_vehicle_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vehicle_id_vehicle_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vehicle_id_vehicle_seq OWNER TO postgres;

--
-- Name: vehicle_id_vehicle_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vehicle_id_vehicle_seq OWNED BY public.vehicle.id_vehicle;


--
-- Name: administrator id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrator ALTER COLUMN id_admin SET DEFAULT nextval('public.administrator_id_admin_seq'::regclass);


--
-- Name: container id_container; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container ALTER COLUMN id_container SET DEFAULT nextval('public.container_id_container_seq'::regclass);


--
-- Name: coordenadas id_coords; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordenadas ALTER COLUMN id_coords SET DEFAULT nextval('public.coordenadas_id_coords_seq'::regclass);


--
-- Name: customer id_customer; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id_customer SET DEFAULT nextval('public.customer_id_customer_seq'::regclass);


--
-- Name: delivery_person id_delivery; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person ALTER COLUMN id_delivery SET DEFAULT nextval('public.delivery_person_id_delivery_seq'::regclass);


--
-- Name: dispatcher id_dispatcher; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dispatcher ALTER COLUMN id_dispatcher SET DEFAULT nextval('public.dispatcher_id_dispatcher_seq'::regclass);


--
-- Name: package id_package; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package ALTER COLUMN id_package SET DEFAULT nextval('public.package_id_package_seq'::regclass);


--
-- Name: tipo id_tipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo ALTER COLUMN id_tipo SET DEFAULT nextval('public.tipo_id_tipo_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: vehicle id_vehicle; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle ALTER COLUMN id_vehicle SET DEFAULT nextval('public.vehicle_id_vehicle_seq'::regclass);


--
-- Data for Name: administrator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.administrator (id_admin, first_name, last_name, address, phone_num, id_auth) FROM stdin;
\.
COPY public.administrator (id_admin, first_name, last_name, address, phone_num, id_auth) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (categoria) FROM stdin;
\.
COPY public.category (categoria) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: container; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.container (id_container, container_num, capacity, address) FROM stdin;
\.
COPY public.container (id_container, container_num, capacity, address) FROM '$$PATH$$/3112.dat';

--
-- Data for Name: coordenadas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coordenadas (id_coords, "time", lat, lng, id_vehicle) FROM stdin;
\.
COPY public.coordenadas (id_coords, "time", lat, lng, id_vehicle) FROM '$$PATH$$/3114.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id_customer, first_name, last_name, address, phone_num, pay_method, id_auth) FROM stdin;
\.
COPY public.customer (id_customer, first_name, last_name, address, phone_num, pay_method, id_auth) FROM '$$PATH$$/3116.dat';

--
-- Data for Name: delivery_person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delivery_person (id_delivery, first_name, last_name, address, phone_num, id_auth, id_vehicle, id_container, status) FROM stdin;
\.
COPY public.delivery_person (id_delivery, first_name, last_name, address, phone_num, id_auth, id_vehicle, id_container, status) FROM '$$PATH$$/3118.dat';

--
-- Data for Name: dispatcher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dispatcher (id_dispatcher, first_name, last_name, address, phone_num, status, id_auth, id_container, id_number) FROM stdin;
\.
COPY public.dispatcher (id_dispatcher, first_name, last_name, address, phone_num, status, id_auth, id_container, id_number) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: package; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.package (id_package, category, source_store, weight_box, height_box, width_box, price, purchase_date, delivery_date, id_container, id_vehicle, id_delivery, estimated_delivery) FROM stdin;
\.
COPY public.package (id_package, category, source_store, weight_box, height_box, width_box, price, purchase_date, delivery_date, id_container, id_vehicle, id_delivery, estimated_delivery) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: tipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo (id_tipo, tipo) FROM stdin;
\.
COPY public.tipo (id_tipo, tipo) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, user_name, user_lastname, user_email, user_password) FROM stdin;
\.
COPY public.users (user_id, user_name, user_lastname, user_email, user_password) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: vehicle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicle (id_vehicle, capacity, license_plate, mechanical_status, latitud, longitud, tiempo, model, brand, tipo) FROM stdin;
\.
COPY public.vehicle (id_vehicle, capacity, license_plate, mechanical_status, latitud, longitud, tiempo, model, brand, tipo) FROM '$$PATH$$/3128.dat';

--
-- Name: administrator_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.administrator_id_admin_seq', 2, true);


--
-- Name: container_id_container_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.container_id_container_seq', 1, true);


--
-- Name: coordenadas_id_coords_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coordenadas_id_coords_seq', 1, false);


--
-- Name: customer_id_customer_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_customer_seq', 1, false);


--
-- Name: delivery_person_id_delivery_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivery_person_id_delivery_seq', 9, true);


--
-- Name: dispatcher_id_dispatcher_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dispatcher_id_dispatcher_seq', 7, true);


--
-- Name: package_id_package_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.package_id_package_seq', 4025, true);


--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_id_tipo_seq', 3, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 19, true);


--
-- Name: vehicle_id_vehicle_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicle_id_vehicle_seq', 24, true);


--
-- Name: administrator administrator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrator
    ADD CONSTRAINT administrator_pkey PRIMARY KEY (id_admin);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (categoria);


--
-- Name: vehicle constraint_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT constraint_name UNIQUE (license_plate);


--
-- Name: container container_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.container
    ADD CONSTRAINT container_pkey PRIMARY KEY (id_container);


--
-- Name: coordenadas coordenadas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordenadas
    ADD CONSTRAINT coordenadas_pkey PRIMARY KEY (id_coords);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id_customer);


--
-- Name: delivery_person delivery_person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person
    ADD CONSTRAINT delivery_person_pkey PRIMARY KEY (id_delivery);


--
-- Name: dispatcher dispatcher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dispatcher
    ADD CONSTRAINT dispatcher_pkey PRIMARY KEY (id_dispatcher);


--
-- Name: dispatcher id_number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dispatcher
    ADD CONSTRAINT id_number UNIQUE (id_number);


--
-- Name: package package_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_pkey PRIMARY KEY (id_package);


--
-- Name: tipo tipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo
    ADD CONSTRAINT tipo_pkey PRIMARY KEY (id_tipo);


--
-- Name: vehicle uniq_license; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT uniq_license UNIQUE (license_plate);


--
-- Name: delivery_person uniq_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person
    ADD CONSTRAINT uniq_user UNIQUE (id_auth);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: vehicle vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_pkey PRIMARY KEY (id_vehicle);


--
-- Name: administrator administrator_id_auth_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrator
    ADD CONSTRAINT administrator_id_auth_fkey FOREIGN KEY (id_auth) REFERENCES public.users(user_id);


--
-- Name: coordenadas coordenadas_id_vehicle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordenadas
    ADD CONSTRAINT coordenadas_id_vehicle_fkey FOREIGN KEY (id_vehicle) REFERENCES public.vehicle(license_plate);


--
-- Name: customer customer_id_auth_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_id_auth_fkey FOREIGN KEY (id_auth) REFERENCES public.users(user_id);


--
-- Name: delivery_person delivery_person_id_auth_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person
    ADD CONSTRAINT delivery_person_id_auth_fkey FOREIGN KEY (id_auth) REFERENCES public.users(user_id);


--
-- Name: delivery_person delivery_person_id_container_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person
    ADD CONSTRAINT delivery_person_id_container_fkey FOREIGN KEY (id_container) REFERENCES public.container(id_container);


--
-- Name: delivery_person delivery_person_id_vehicle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_person
    ADD CONSTRAINT delivery_person_id_vehicle_fkey FOREIGN KEY (id_vehicle) REFERENCES public.vehicle(id_vehicle);


--
-- Name: dispatcher dispatcher_id_auth_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dispatcher
    ADD CONSTRAINT dispatcher_id_auth_fkey FOREIGN KEY (id_auth) REFERENCES public.users(user_id);


--
-- Name: dispatcher dispatcher_id_container_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dispatcher
    ADD CONSTRAINT dispatcher_id_container_fkey FOREIGN KEY (id_container) REFERENCES public.container(id_container);


--
-- Name: package package_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_category_fkey FOREIGN KEY (category) REFERENCES public.category(categoria);


--
-- Name: package package_id_container_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_container_fkey FOREIGN KEY (id_container) REFERENCES public.container(id_container);


--
-- Name: package package_id_delivery_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_delivery_fkey FOREIGN KEY (id_delivery) REFERENCES public.delivery_person(id_delivery);


--
-- Name: package package_id_vehicle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.package
    ADD CONSTRAINT package_id_vehicle_fkey FOREIGN KEY (id_vehicle) REFERENCES public.vehicle(id_vehicle);


--
-- Name: vehicle vehicle_tipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle
    ADD CONSTRAINT vehicle_tipo_fkey FOREIGN KEY (tipo) REFERENCES public.tipo(id_tipo);


--
-- PostgreSQL database dump complete
--

